$(function(){
    $('.selectpicker').selectpicker();
});