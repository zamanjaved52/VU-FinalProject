<?php $__env->startSection('content'); ?>
<div class="login-box">
    <div class="login-logo">
        <a href="#">
            <?php echo e(trans('panel.site_title')); ?>

        </a>
    </div>
    <div class="login-box-body">
        <p class="login-box-msg">
            <?php echo e(trans('global.reset_password')); ?>

        </p>
        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo e(csrf_field()); ?>

            <div>
                <div class="form-group has-feedback">
                    <input type="email" name="email" class="form-control" required="autofocus" placeholder="<?php echo e(trans('global.login_email')); ?>">
                    <?php if($errors->has('email')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('email')); ?>

                        </p>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-xs-6">

                    </div>
                    <div class="col-xs-6">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">
                            <?php echo e(trans('global.reset_password')); ?>

                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xammp7\htdocs\finnal\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>