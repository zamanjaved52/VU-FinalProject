<?php echo e($slot); ?>

<?php /**PATH E:\xammp7\htdocs\finnal\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>