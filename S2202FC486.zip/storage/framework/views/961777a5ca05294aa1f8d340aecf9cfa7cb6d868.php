<?php echo e($slot); ?>

<?php /**PATH E:\xammp7\htdocs\Laravel-User-Admin-Approval\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>