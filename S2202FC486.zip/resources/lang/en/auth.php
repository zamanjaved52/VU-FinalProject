<?php

return [
    'failed'   => 'Username does not match with the records in database.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
];
