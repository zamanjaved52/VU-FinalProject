<?php

return [
    'site_title' => 'Budget Planner ',
];
